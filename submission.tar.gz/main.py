import sys
import json
import time

# Try to import the rust engine
try:
    import rust_engine
    ENGINE_LOADED = True
except ImportError:
    ENGINE_LOADED = False

last_obs = None
total_weeds_fed = 0

def _extract_weeds(prev_obs, curr_obs):
    """
    Returns a list of (day, k) for unambiguously spawned weeds.
    Returns [] if the board state has any ambiguity (e.g. natural decay vs DIG).
    """
    day = curr_obs.get("day", 0) - 1 # The weeds spawned at the end of the previous day
    if day < 0:
        return []
        
    weeds = []
    k = 0
    
    # Iterate exactly in the order of _spawn_weeds
    for farm_idx in [0, 1]:
        prev_farm = prev_obs["farms"][farm_idx]
        curr_farm = curr_obs["farms"][farm_idx]
        for y in range(10):
            for x in range(10):
                prev_tile = prev_farm["tiles"][y][x]
                curr_tile = curr_farm["tiles"][y][x]
                
                curr_is_weed = isinstance(curr_tile, dict) and curr_tile.get("kind") == "WEED"
                prev_is_weed = isinstance(prev_tile, dict) and prev_tile.get("kind") == "WEED"
                
                if curr_tile is None:
                    # Tile is empty now -> MUST have been empty entering _spawn_weeds.
                    k += 1
                elif curr_is_weed:
                    if prev_tile is None or prev_tile == "LOCKED":
                        # Was empty/locked, now a weed -> MUST have been a newly spawned weed.
                        weeds.append((day, k))
                        k += 1
                    elif prev_is_weed:
                        # Already a weed -> Did not consume RNG.
                        pass
                    else:
                        # Ambiguous: Could have died naturally (0 RNG calls) or been DIGged and then spawned (1 RNG call).
                        # Abort this day to prevent desyncing `k`.
                        return []
                elif curr_tile == "LOCKED":
                    pass
                else:
                    # It's a plant or structure now. If they planted/built on step 23, it was NOT empty entering _spawn_weeds.
                    pass
                    
    return weeds

def agent(obs):
    global last_obs, total_weeds_fed
    start_time = time.perf_counter()
    
    # Initialize engine on turn 0
    if obs["step"] == 0 and ENGINE_LOADED:
        rust_engine.init_engine()
        
    # If this is Day X > 0, Hour 0, we can extract weeds spawned at the end of Day X-1
    if obs["step"] > 0 and obs["step"] % 24 == 0 and last_obs is not None and ENGINE_LOADED:
        weeds = _extract_weeds(last_obs, obs)
        for w in weeds:
            rust_engine.add_weed_observation(w[0], w[1])
            total_weeds_fed += 1
            print(f"[DEBUG] Fed weed observation: Day {w[0]}, k={w[1]}. Total fed: {total_weeds_fed}")
            
    # Save the Hour 23 observation for the next day's check
    if obs["step"] % 24 == 23:
        last_obs = obs
        
    if ENGINE_LOADED:
        # Strict Budgeting Guardrail:
        elapsed_ms = (time.perf_counter() - start_time) * 1000.0
        remaining_budget_ms = max(10.0, 800.0 - elapsed_ms)
        
        action_json, log_msg = rust_engine.get_action_and_stall(int(remaining_budget_ms))
        if log_msg:
            print(log_msg)
        return json.loads(action_json)
    else:
        # Fallback if engine fails to load
        return {"farmer": ["PASS"], "hands": [], "market": []}
